package observer_design_pattern;

public class Abonat implements Observer {

	private String name;
	
	Abonat(String a_name){
		name = a_name;
	}
	//----------------------------------//
	
	public void Subscribe(Magazin mag){
		boolean flag =
		mag.addObserver(this);
		
		if(flag)
		System.out.print("\n" + name +" s-a abonat la magazin!" + "\n");
		else
			System.out.println(" Exista deja persoana abonata");
	}
	
	public void Unsubscribe(Magazin mag){
		boolean flag =
				mag.deleteObserver(this);
		
		if(flag)
		System.out.print("\n" + name + " s-a dezabonat de la magazin!" + "\n");
		else
			System.out.println("\nNu exista persoana in lista de abonati\n");
	}
	
	@Override
	public void update(String msg) {
		System.out.print("\n"+ name +" reducere valabila de: " + msg + "\n");
	}
	
	public String getName() {
    	return name;
  	}
}
