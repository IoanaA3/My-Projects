package observer_design_pattern;

import java.util.*;

public class Magazin implements Subject{

	private List<Observer> obs = new ArrayList<>(); 
	
	
	@Override
	public boolean addObserver(Observer o) {
		for(int i=0;i < obs.size();i++)
		{			
			if(((Abonat)obs.get(i)).getName().equals(((Abonat)o).getName())){
				return false;
			}			
		}
		obs.add(o);
			return true;
	}

	@Override
	public boolean deleteObserver(Observer o) {		
		for(int i=0;i < obs.size();i++)
		{			
			if(((Abonat)obs.get(i)).getName().equals(((Abonat)o).getName())){					
				obs.remove((Abonat)obs.get(i));				
				return true;
			}
		}
		return false;
	}
	
	//----------------------------------//
	@Override
	public void notifyObserver(String text) {
		for (Observer observer : obs) {
            observer.update(text);
        }
	}
	//----------------Pentru a putea afisa lista pe ecran------------------//
	public String getList(){
		String lista = new String();
		
		for(int i=0;i < obs.size();i++)
		lista = lista + "  " + ((Abonat)obs.get(i)).getName() + "\n";
		
		return lista;
	}
}
