package observer_design_pattern;

public interface Observer {

	public void update(String msg);
}
