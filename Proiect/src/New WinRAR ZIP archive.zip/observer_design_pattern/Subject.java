package observer_design_pattern;

public interface Subject {

	public boolean addObserver(Observer o);
	public boolean deleteObserver(Observer o);
	public void notifyObserver(String text);
}
